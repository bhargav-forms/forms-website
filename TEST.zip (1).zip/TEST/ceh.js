const questionsData = [
  {
    question: "1. What does CEH primarily focus on?",
    options: [
      "System administration techniques",
      "Cybersecurity project management",
      "Ethical hacking and penetration testing",
      "Database tuning strategies"
    ],
    correctAnswer: "Ethical hacking and penetration testing"
  },
  {
    question: "2. What is the first phase of ethical hacking?",
    options: [
      "Scanning",
      "Gaining Access",
      "Enumeration",
      "Reconnaissance"
    ],
    correctAnswer: "Reconnaissance"
  },
  {
    question: "3. What type of attack intercepts communication between two systems?",
    options: [
      "Brute force attack",
      "Man-in-the-middle attack",
      "Denial-of-service attack",
      "Phishing"
    ],
    correctAnswer: "Man-in-the-middle attack"
  },
  {
    question: "4. Which tool is commonly used for network packet capturing?",
    options: ["Nmap", "Wireshark", "Nessus", "Metasploit"],
    correctAnswer: "Wireshark"
  },
  {
    question: "5. Which of the following is considered social engineering?",
    options: [
      "SQL Injection",
      "ARP Spoofing",
      "Phishing emails",
      "Session hijacking"
    ],
    correctAnswer: "Phishing emails"
  },
  {
    question: "6. Which protocol does HTTPS rely on for encryption?",
    options: ["FTP", "SSH", "SSL/TLS", "IPSec"],
    correctAnswer: "SSL/TLS"
  },
  {
    question: "7. What is the main goal of privilege escalation?",
    options: [
      "Crash the system",
      "Gain unauthorized administrative access",
      "Change the operating system",
      "Update antivirus rules"
    ],
    correctAnswer: "Gain unauthorized administrative access"
  },
  {
    question: "8. What’s a common use of the tool Nmap?",
    options: ["Hash cracking", "Firewall configuration", "Port scanning", "Password reset"],
    correctAnswer: "Port scanning"
  },
  {
    question: "9. What type of malware demands payment to restore access?",
    options: ["Adware", "Spyware", "Ransomware", "Worm"],
    correctAnswer: "Ransomware"
  },
  {
    question: "10. Which of the following is used for exploiting vulnerabilities?",
    options: ["Snort", "Metasploit", "Burp Suite", "Nessus"],
    correctAnswer: "Metasploit"
  },
  {
    question: "11. What is footprinting?",
    options: [
      "Changing DNS records",
      "Covering hacker tracks",
      "Gathering information about a target",
      "Flooding network ports"
    ],
    correctAnswer: "Gathering information about a target"
  },
  {
    question: "12. What is a zero-day vulnerability?",
    options: [
      "A vulnerability patched on day zero",
      "A known flaw with a workaround",
      "A flaw with no existing patch yet",
      "A previously removed backdoor"
    ],
    correctAnswer: "A flaw with no existing patch yet"
  },
  {
    question: "13. Which port is used by DNS by default?",
    options: ["21", "25", "53", "443"],
    correctAnswer: "53"
  },
  {
    question: "14. What does SQL Injection target?",
    options: ["Router memory", "DNS records", "Databases", "File systems"],
    correctAnswer: "Databases"
  },
  {
    question: "15. Which phase includes maintaining access to a compromised system?",
    options: ["Scanning", "Covering tracks", "Enumeration", "Maintaining Access"],
    correctAnswer: "Maintaining Access"
  }
];

const container = document.getElementById("questions-container");

// Render all questions
questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(
          opt =>
            `<label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label>`
        )
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

// Timer: 15 minutes
let duration = 15 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;
  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

// Submit handler
document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);

  let score = 0;
  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.style.background = "#e0f7fa";
  resultBox.style.border = "1px solid #00838f";
  resultBox.style.color = "#004d40";
  resultBox.style.padding = "1.5rem";
  resultBox.style.margin = "2rem auto";
  resultBox.style.width = "80%";
  resultBox.style.borderRadius = "8px";
  resultBox.style.textAlign = "center";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 12
        ? "Great job! You're an ethical hacking pro."
        : score >= 8
        ? "Nice effort! A bit more practice will get you there."
        : "Keep going—review the fundamentals and come back stronger."
    }</p>
  `;

  document.body.appendChild(resultBox);
});
