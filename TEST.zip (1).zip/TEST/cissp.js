const questionsData = [
  // Questions 1–15
  {
    question: "1. What is the primary goal of information security within an organization?",
    options: ["Data mining", "Ensuring confidentiality, integrity, and availability", "Marketing reach", "Optimizing storage"],
    correctAnswer: "Ensuring confidentiality, integrity, and availability"
  },
  {
    question: "2. Which security model is primarily concerned with preventing unauthorized reading of data?",
    options: ["Bell-LaPadula", "Clark-Wilson", "Biba", "Brewer-Nash"],
    correctAnswer: "Bell-LaPadula"
  },
  {
    question: "3. Risk = Threat × ______?",
    options: ["Mitigation", "Control", "Vulnerability", "Asset"],
    correctAnswer: "Vulnerability"
  },
  {
    question: "4. What is the primary function of a firewall?",
    options: ["Encrypt sensitive data", "Block physical access", "Filter incoming and outgoing traffic", "Backup files"],
    correctAnswer: "Filter incoming and outgoing traffic"
  },
  {
    question: "5. Which access control model is most restrictive and centrally managed?",
    options: ["Discretionary Access Control", "Mandatory Access Control", "Role-Based Access Control", "Rule-Based Access Control"],
    correctAnswer: "Mandatory Access Control"
  },
  {
    question: "6. What kind of control is an access badge?",
    options: ["Physical control", "Administrative control", "Logical control", "Procedural control"],
    correctAnswer: "Physical control"
  },
  {
    question: "7. What is the FIRST step in a risk assessment process?",
    options: ["Assign mitigation steps", "Perform impact analysis", "Identify assets", "Calculate annual loss expectancy"],
    correctAnswer: "Identify assets"
  },
  {
    question: "8. What protocol is typically used to secure HTTP traffic?",
    options: ["SSL/TLS", "IPSec", "SSH", "SFTP"],
    correctAnswer: "SSL/TLS"
  },
  {
    question: "9. What is shoulder surfing?",
    options: ["Using software to track emails", "Stealing passwords via network sniffing", "Watching over someone’s shoulder to gather information", "Intercepting wireless signals"],
    correctAnswer: "Watching over someone’s shoulder to gather information"
  },
  {
    question: "10. Which of the following best describes separation of duties?",
    options: ["Limiting system access to authorized users", "Assigning backup operators", "Preventing one person from having total control over a process", "Requiring biometric authentication"],
    correctAnswer: "Preventing one person from having total control over a process"
  },
  {
    question: "11. What technique ensures that a message has not been altered during transit?",
    options: ["Confidentiality", "Integrity", "Availability", "Encryption"],
    correctAnswer: "Integrity"
  },
  {
    question: "12. Which law focuses on protecting healthcare-related information in the U.S.?",
    options: ["FERPA", "HIPAA", "SOX", "PCI-DSS"],
    correctAnswer: "HIPAA"
  },
  {
    question: "13. Which backup method backs up only files that have changed since the last full backup?",
    options: ["Full backup", "Differential backup", "Incremental backup", "Snapshot"],
    correctAnswer: "Incremental backup"
  },
  {
    question: "14. In symmetric encryption, what is shared between sender and receiver?",
    options: ["Public key", "Private key", "Same key", "Digital certificate"],
    correctAnswer: "Same key"
  },
  {
    question: "15. Which of the following attacks involves injecting malicious input through a web form?",
    options: ["Phishing", "SQL Injection", "DoS", "Sniffing"],
    correctAnswer: "SQL Injection"
  },

  // Questions 16–30
  {
    question: "16. What does the principle of least privilege enforce?",
    options: ["Users can access everything", "Only the highest role can perform tasks", "Users get access only to what they need to perform their job", "Access is granted based on seniority"],
    correctAnswer: "Users get access only to what they need to perform their job"
  },
  {
    question: "17. What is the purpose of a digital signature?",
    options: ["Encrypt documents", "Provide anonymity", "Ensure authenticity and integrity", "Prevent phishing"],
    correctAnswer: "Ensure authenticity and integrity"
  },
  {
    question: "18. What is the main concern of social engineering?",
    options: ["Firewall misconfiguration", "Exploiting human behavior", "DDOS attacks", "Malware payloads"],
    correctAnswer: "Exploiting human behavior"
  },
  {
    question: "19. What is dumpster diving in information security?",
    options: ["Searching for free software online", "Looking through trash to find sensitive info", "A type of network sniffing", "A method of SQL Injection"],
    correctAnswer: "Looking through trash to find sensitive info"
  },
  {
    question: "20. Which of the following is an example of multifactor authentication?",
    options: ["Password and security question", "PIN and password", "Fingerprint and password", "Username and password"],
    correctAnswer: "Fingerprint and password"
  },
  {
    question: "21. What is an SLA?",
    options: ["Secure Login Agreement", "System Logging Architecture", "Service Level Agreement", "System-Level Access"],
    correctAnswer: "Service Level Agreement"
  },
  {
    question: "22. Which term refers to measures taken after a security breach has occurred?",
    options: ["Preventive controls", "Detective controls", "Corrective controls", "Deterrent controls"],
    correctAnswer: "Corrective controls"
  },
  {
    question: "23. What is the function of a honeypot in cybersecurity?",
    options: ["Speed up internet access", "Store logs", "Lure attackers into a controlled environment", "Create backup storage"],
    correctAnswer: "Lure attackers into a controlled environment"
  },
  {
    question: "24. In the context of CISSP, what does DRP stand for?",
    options: ["Data Recovery Plan", "Disaster Recovery Plan", "Digital Resource Protocol", "Data Redundancy Protocol"],
    correctAnswer: "Disaster Recovery Plan"
  },
  {
    question: "25. What is the main goal of cryptography?",
    options: ["Reducing storage needs", "Increasing data availability", "Protecting confidentiality and integrity", "Automating logs"],
    correctAnswer: "Protecting confidentiality and integrity"
  },
  {
    question: "26. What is a botnet?",
    options: ["A new internet protocol", "A legitimate server farm", "A group of compromised systems under control of an attacker", "A type of biometric reader"],
    correctAnswer: "A group of compromised systems under control of an attacker"
  },
  {
    question: "27. Which cloud service model provides virtual machines, storage, and networks?",
    options: ["SaaS", "PaaS", "IaaS", "XaaS"],
    correctAnswer: "IaaS"
  },
  {
    question: "28. What type of malware poses as a legitimate program?",
    options: ["Worm", "Rootkit", "Trojan Horse", "Ransomware"],
    correctAnswer: "Trojan Horse"
  },
  {
    question: "29. What is the main purpose of a business impact analysis (BIA)?",
    options: ["Identify vulnerabilities", "Determine how security affects profits", "Evaluate the effects of disruptions", "Prevent attacks on data centers"],
    correctAnswer: "Evaluate the effects of disruptions"
  },
  {
    question: "30. What does ISO/IEC 27001 focus on?",
    options: ["Cloud service pricing", "Identity verification", "Information security management systems (ISMS)", "Network design protocols"],
    correctAnswer: "Information security management systems (ISMS)"
  }
];

// === Render all questions ===
const container = document.getElementById("questions-container");

questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(
          opt =>
            `<label><input type="radio" name="q${index}" value="${opt}" /> ${opt}</label>`
        )
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

// === Start 30-minute countdown ===


// === Start 30-minute countdown ===
let duration = 30 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;

  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

// === Show score on submit ===
document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);

  let score = 0;

  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.style.background = "#dff0d8";
  resultBox.style.border = "1px solid #3c763d";
  resultBox.style.color = "#3c763d";
  resultBox.style.padding = "1.5rem";
  resultBox.style.margin = "2rem auto";
  resultBox.style.width = "80%";
  resultBox.style.borderRadius = "8px";
  resultBox.style.textAlign = "center";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 24
        ? "Excellent work!"
        : score >= 15
        ? "Good job, keep practicing!"
        : "Don't worry, review the material and try again."
    }</p>
  `;

  document.body.appendChild(resultBox);
});







