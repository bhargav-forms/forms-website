const questionsData = [
  {
    question: "1. What is Google Compute Engine used for?",
    options: ["Object storage", "Relational databases", "Virtual machines", "App deployment automation"],
    correctAnswer: "Virtual machines"
  },
  {
    question: "2. Which GCP service provides scalable object storage?",
    options: ["Cloud SQL", "Compute Engine", "Cloud Storage", "App Engine"],
    correctAnswer: "Cloud Storage"
  },
  {
    question: "3. What is the primary purpose of Google Cloud IAM?",
    options: ["Monitor billing usage", "Manage VMs", "Control access to resources", "Create dashboards"],
    correctAnswer: "Control access to resources"
  },
  {
    question: "4. Which service allows serverless application deployment?",
    options: ["Cloud Run", "Cloud Spanner", "Cloud SQL", "Cloud Storage"],
    correctAnswer: "Cloud Run"
  },
  {
    question: "5. What GCP tool provides real-time logging and metrics?",
    options: ["Cloud Deployment Manager", "Stackdriver", "Cloud CDN", "BigQuery"],
    correctAnswer: "Stackdriver"
  },
  {
    question: "6. Which GCP service is ideal for big data analytics using SQL-like queries?",
    options: ["Cloud SQL", "BigQuery", "Firestore", "Cloud Functions"],
    correctAnswer: "BigQuery"
  },
  {
    question: "7. Which service helps manage containers on GCP?",
    options: ["Cloud CDN", "Kubernetes Engine", "Cloud Functions", "App Engine"],
    correctAnswer: "Kubernetes Engine"
  },
  {
    question: "8. What is the function of Cloud CDN?",
    options: ["Create API endpoints", "Compress images", "Deliver content with low latency", "Protect networks"],
    correctAnswer: "Deliver content with low latency"
  },
  {
    question: "9. GCP regions contain one or more ______?",
    options: ["Buckets", "Instances", "Zones", "Projects"],
    correctAnswer: "Zones"
  },
  {
    question: "10. Which GCP service is used for relational databases with full SQL support?",
    options: ["Cloud Firestore", "BigQuery", "Cloud SQL", "Datastore"],
    correctAnswer: "Cloud SQL"
  },
  {
    question: "11. What does Google Cloud App Engine provide?",
    options: ["A virtual machine creation tool", "Infrastructure monitoring", "A platform for running scalable web apps", "Storage for binary data"],
    correctAnswer: "A platform for running scalable web apps"
  },
  {
    question: "12. Which service is designed for long-term archival storage?",
    options: ["Nearline Storage", "Coldline Storage", "Standard Storage", "Cloud Storage Archive"],
    correctAnswer: "Cloud Storage Archive"
  },
  {
    question: "13. What is the purpose of VPC in Google Cloud?",
    options: ["Deploy containers", "Encrypt data", "Define virtual network boundaries", "Run serverless functions"],
    correctAnswer: "Define virtual network boundaries"
  },
  {
    question: "14. What is the use of Cloud Pub/Sub?",
    options: ["Monitoring SQL performance", "Transmitting encrypted emails", "Messaging for decoupled systems", "Creating cloud-based spreadsheets"],
    correctAnswer: "Messaging for decoupled systems"
  },
  {
    question: "15. Which service is used to define and automate infrastructure in GCP?",
    options: ["Cloud Scheduler", "Cloud Build", "Cloud Deployment Manager", "Cloud Composer"],
    correctAnswer: "Cloud Deployment Manager"
  }
];

// Render Questions
const container = document.getElementById("questions-container");

questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(
          opt =>
            `<label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label>`
        )
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

// 15-minute Countdown Timer
let duration = 15 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;
  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

// Submit & Score
document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);

  let score = 0;
  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.className = "result-box";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 12
        ? "Outstanding! You’re cloud-certified ready! ☁️🎓"
        : score >= 8
        ? "Nice effort! Review a bit more and level up. 💪"
        : "No worries — practice makes perfect. Try again soon!"
    }</p>
  `;
  document.body.appendChild(resultBox);
});
