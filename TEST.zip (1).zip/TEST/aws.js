const questionsData = [
  {
    question: "1. What service provides scalable compute capacity in the AWS cloud?",
    options: ["Amazon EC2", "Amazon RDS", "Amazon S3", "Amazon SNS"],
    correctAnswer: "Amazon EC2"
  },
  {
    question: "2. What AWS service is best for object storage?",
    options: ["Amazon EBS", "Amazon Glacier", "Amazon RDS", "Amazon S3"],
    correctAnswer: "Amazon S3"
  },
  {
    question: "3. Which AWS database is fully managed and supports SQL?",
    options: ["Amazon Redshift", "Amazon DynamoDB", "Amazon RDS", "Amazon Neptune"],
    correctAnswer: "Amazon RDS"
  },
  {
    question: "4. What service allows you to run code without provisioning servers?",
    options: ["EC2 Auto Scaling", "Elastic Beanstalk", "AWS Lambda", "AWS ECS"],
    correctAnswer: "AWS Lambda"
  },
  {
    question: "5. What AWS feature automatically distributes incoming application traffic?",
    options: ["Route 53", "CloudWatch", "Elastic Load Balancing", "AWS Auto Scaling"],
    correctAnswer: "Elastic Load Balancing"
  },
  {
    question: "6. What does Amazon CloudWatch do?",
    options: ["Stores files", "Monitors AWS resources", "Manages security groups", "Encrypts S3 buckets"],
    correctAnswer: "Monitors AWS resources"
  },
  {
    question: "7. Which service helps manage infrastructure as code?",
    options: ["AWS CloudTrail", "AWS Config", "AWS CloudFormation", "Amazon Inspector"],
    correctAnswer: "AWS CloudFormation"
  },
  {
    question: "8. What storage class is best for infrequently accessed data?",
    options: ["S3 Standard", "S3 One Zone", "S3 Intelligent-Tiering", "S3 Glacier"],
    correctAnswer: "S3 Glacier"
  },
  {
    question: "9. Which tool helps estimate AWS costs?",
    options: ["Billing Console", "AWS Budgets", "AWS Pricing Calculator", "Trusted Advisor"],
    correctAnswer: "AWS Pricing Calculator"
  },
  {
    question: "10. IAM policies are written in which format?",
    options: ["XML", "YAML", "JSON", "CSV"],
    correctAnswer: "JSON"
  },
  {
    question: "11. Which service helps manage access to AWS resources securely?",
    options: ["Amazon Cognito", "IAM", "AWS Shield", "AWS GuardDuty"],
    correctAnswer: "IAM"
  },
  {
    question: "12. What is the maximum size of a single S3 object?",
    options: ["1 TB", "2 TB", "5 TB", "10 TB"],
    correctAnswer: "5 TB"
  },
  {
    question: "13. Which database is designed for high-volume, key-value access?",
    options: ["Amazon RDS", "Amazon Neptune", "Amazon Redshift", "Amazon DynamoDB"],
    correctAnswer: "Amazon DynamoDB"
  },
  {
    question: "14. What is AWS Availability Zone?",
    options: ["Backup region", "Data center in a region", "Edge location", "VPC segment"],
    correctAnswer: "Data center in a region"
  },
  {
    question: "15. What service offers DDoS protection?",
    options: ["AWS WAF", "AWS Shield", "Amazon Macie", "Amazon Detective"],
    correctAnswer: "AWS Shield"
  }
];

const container = document.getElementById("questions-container");

questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(opt => `<label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label>`)
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

let duration = 15 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;
  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);

  let score = 0;
  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.style.background = "#fff8e1";
  resultBox.style.border = "1px solid #ffb300";
  resultBox.style.color = "#795548";
  resultBox.style.padding = "1.5rem";
  resultBox.style.margin = "2rem auto";
  resultBox.style.width = "80%";
  resultBox.style.borderRadius = "8px";
  resultBox.style.textAlign = "center";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 12
        ? "You're cloud-ready! ☁️🚀"
        : score >= 8
        ? "Not bad! Review a bit more and you'll ace it. 💪"
        : "Keep practicing! The cloud awaits. 🌥️"
    }</p>
  `;

  document.body.appendChild(resultBox);
});
