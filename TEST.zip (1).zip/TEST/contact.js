document.addEventListener("DOMContentLoaded", () => {
  const captchaLabel = document.getElementById("captcha-label");
  const captchaInput = document.getElementById("captcha-input");
  const form = document.getElementById("contactForm");
  const message = document.getElementById("form-message");

  const num1 = Math.floor(Math.random() * 10) + 1;
  const num2 = Math.floor(Math.random() * 10) + 1;
  const answer = num1 + num2;

  captchaLabel.textContent = `What is ${num1} + ${num2}?`;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (parseInt(captchaInput.value) === answer) {
      message.textContent = "✅ Thank you! We'll be in touch soon.";
      message.style.color = "green";
      form.reset();
    } else {
      message.textContent = "❌ Incorrect answer. Please try again.";
      message.style.color = "red";
    }
  });
});
