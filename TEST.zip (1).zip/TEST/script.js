
const tests = [
  {
    title: "CISSP",
    link: "cissp.html",
    duration: "30 minutes",
    questions: "30"
  },
  {
    title: "CISM",
    link: "cism.html",
    duration: "15 minutes",
    questions: "15"
  },
  {
    title: "CEH v12",
    link: "ceh.html",
    duration: "15 minutes",
    questions: "15"
  },
  {
    title: "AWS Solutions Architect",
    link: "aws.html",
    duration: "15 minutes",
    questions: "15"
  },
  {
    title: "Azure Fundamentals",
    link: "azure.html",
    duration: "15 minutes",
    questions: "15"
  },
  {
    title: "Google Cloud Associate",
    link: "gcp.html",
    duration: "15 minutes",
    questions: "15"
  }
];

const container = document.getElementById("test-container");
const searchInput = document.getElementById("search");
const themeToggle = document.getElementById("theme-toggle");

function renderCards(data) {
  container.innerHTML = "";
  data.forEach(test => {
    const card = document.createElement("div");
    card.className = "test-card";
    card.innerHTML = `
      <h3>${test.title}</h3>
      <div class="test-meta">
        <span>⏱ ${test.duration}</span>
        <span>📝 ${test.questions} Questions</span>
      </div>
      <a href="${test.link}" target="_blank">Start Test →</a>
    `;
    container.appendChild(card);
  });
}

renderCards(tests);

// Search filter
searchInput.addEventListener("input", () => {
  const term = searchInput.value.toLowerCase();
  const filtered = tests.filter(test =>
    test.title.toLowerCase().includes(term)
  );
  renderCards(filtered);
});

// Dark mode toggle
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});
