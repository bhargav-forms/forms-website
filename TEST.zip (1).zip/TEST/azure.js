const questionsData = [
  {
    question: "1. What is Azure's primary service for hosting virtual machines?",
    options: ["Azure App Service", "Azure Virtual Machines", "Azure Kubernetes Service", "Azure Functions"],
    correctAnswer: "Azure Virtual Machines"
  },
  {
    question: "2. Which Azure service is used for storing unstructured data such as images, videos, and documents?",
    options: ["Azure SQL Database", "Azure Blob Storage", "Azure Table Storage", "Azure File Storage"],
    correctAnswer: "Azure Blob Storage"
  },
  {
    question: "3. What is the purpose of Azure Active Directory (Azure AD)?",
    options: ["To manage virtual machines", "To provide identity and access management", "To monitor application performance", "To store relational data"],
    correctAnswer: "To provide identity and access management"
  },
  {
    question: "4. Which Azure service is best suited for building and deploying containerized applications?",
    options: ["Azure Kubernetes Service (AKS)", "Azure Functions", "Azure Logic Apps", "Azure App Service"],
    correctAnswer: "Azure Kubernetes Service (AKS)"
  },
  {
    question: "5. What is the primary use of Azure Monitor?",
    options: ["To manage virtual networks", "To monitor and analyze the performance of applications and resources", "To deploy machine learning models", "To create and manage databases"],
    correctAnswer: "To monitor and analyze the performance of applications and resources"
  },
  {
    question: "6. Which Azure service is used for serverless computing?",
    options: ["Azure Virtual Machines", "Azure Functions", "Azure App Service", "Azure Logic Apps"],
    correctAnswer: "Azure Functions"
  },
  {
    question: "7. What is the purpose of Azure Resource Manager (ARM)?",
    options: ["To manage Azure resources through templates", "To monitor application performance", "To provide identity and access management", "To store unstructured data"],
    correctAnswer: "To manage Azure resources through templates"
  },
  {
    question: "8. Which Azure service is designed for big data analytics?",
    options: ["Azure Data Lake", "Azure SQL Database", "Azure Blob Storage", "Azure Functions"],
    correctAnswer: "Azure Data Lake"
  },
  {
    question: "9. What is the purpose of Azure DevOps?",
    options: ["To manage virtual machines", "To provide tools for continuous integration and delivery", "To monitor application performance", "To store relational data"],
    correctAnswer: "To provide tools for continuous integration and delivery"
  },
  {
    question: "10. Which Azure service is used for hosting relational databases?",
    options: ["Azure Cosmos DB", "Azure SQL Database", "Azure Blob Storage", "Azure Table Storage"],
    correctAnswer: "Azure SQL Database"
  },
  {
    question: "11. What is the purpose of Azure Traffic Manager?",
    options: ["To manage virtual networks", "To distribute network traffic across multiple regions", "To monitor application performance", "To deploy machine learning models"],
    correctAnswer: "To distribute network traffic across multiple regions"
  },
  {
    question: "12. Which Azure service is best for real-time data processing?",
    options: ["Azure Stream Analytics", "Azure Data Factory", "Azure SQL Database", "Azure Blob Storage"],
    correctAnswer: "Azure Stream Analytics"
  },
  {
    question: "13. What is the purpose of Azure Logic Apps?",
    options: ["To automate workflows and integrate applications", "To host virtual machines", "To store unstructured data", "To monitor application performance"],
    correctAnswer: "To automate workflows and integrate applications"
  },
  {
    question: "14. Which Azure service is used for content delivery and caching?",
    options: ["Azure CDN", "Azure Blob Storage", "Azure SQL Database", "Azure Functions"],
    correctAnswer: "Azure CDN"
  },
  {
    question: "15. What is the purpose of Azure Backup?",
    options: ["To monitor application performance", "To provide data backup and recovery solutions", "To deploy machine learning models", "To manage virtual networks"],
    correctAnswer: "To provide data backup and recovery solutions"
  }
];

const container = document.getElementById("questions-container");

// Render questions
questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(opt => `<label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label>`)
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

// 15-minute timer
let duration = 15 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;
  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

// Submission + scoring
document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);
  let score = 0;

  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.className = "result-box";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 12
        ? "Cloud confidence achieved! 🟦☁️"
        : score >= 8
        ? "Almost there—review and try again!"
        : "Don’t worry, Azure mastery takes practice."
    }</p>
  `;

  document.body.appendChild(resultBox);
});
