const questionsData = [
  {
    question: "1. What is the primary focus of CISM certification?",
    options: ["Penetration testing", "System development", "Information security management", "Network troubleshooting"],
    correctAnswer: "Information security management"
  },
  {
    question: "2. Which domain covers incident response and recovery in CISM?",
    options: ["Governance", "Risk Management", "Security Program Development", "Incident Management"],
    correctAnswer: "Incident Management"
  },
  {
    question: "3. Who is ultimately responsible for information security in an organization?",
    options: ["The security team", "IT manager", "CEO", "The board of directors"],
    correctAnswer: "The board of directors"
  },
  {
    question: "4. What does risk appetite mean?",
    options: ["Risk that must be accepted", "Total risk in the system", "Amount of risk an organization is willing to accept", "Risk being transferred"],
    correctAnswer: "Amount of risk an organization is willing to accept"
  },
  {
    question: "5. What's the purpose of a security policy?",
    options: ["To allow unrestricted access", "To define acceptable system configurations", "To monitor users silently", "To encrypt user data"],
    correctAnswer: "To define acceptable system configurations"
  },
  {
    question: "6. What’s an example of a technical control?",
    options: ["Security awareness training", "Firewall configuration", "Hiring procedures", "Background checks"],
    correctAnswer: "Firewall configuration"
  },
  {
    question: "7. What is residual risk?",
    options: ["Risk removed by controls", "Risk transferred to a third party", "Remaining risk after controls are applied", "Zero risk"],
    correctAnswer: "Remaining risk after controls are applied"
  },
  {
    question: "8. What is an important part of business continuity planning?",
    options: ["Budget forecasts", "Risk registers", "Disaster recovery testing", "Employee satisfaction surveys"],
    correctAnswer: "Disaster recovery testing"
  },
  {
    question: "9. What’s the main goal of risk management?",
    options: ["Eliminating all threats", "Transferring responsibility", "Ensuring risk aligns with business objectives", "Maximizing asset use"],
    correctAnswer: "Ensuring risk aligns with business objectives"
  },
  {
    question: "10. A control that detects policy violations is a ________ control.",
    options: ["Preventive", "Corrective", "Detective", "Directive"],
    correctAnswer: "Detective"
  },
  {
    question: "11. How should security controls be chosen?",
    options: ["By regulatory agencies only", "Based on IT department preferences", "Through cost-benefit analysis and risk assessment", "To match competitors"],
    correctAnswer: "Through cost-benefit analysis and risk assessment"
  },
  {
    question: "12. What is ISO/IEC 27005 focused on?",
    options: ["Security auditing", "Risk management", "Software development", "Cloud architecture"],
    correctAnswer: "Risk management"
  },
  {
    question: "13. Which of these is most important in classifying assets?",
    options: ["Storage capacity", "Monetary value only", "Importance to business operations", "Backup frequency"],
    correctAnswer: "Importance to business operations"
  },
  {
    question: "14. Which report shows known vulnerabilities in an asset?",
    options: ["Threat matrix", "Change log", "Vulnerability scan report", "Penetration test summary"],
    correctAnswer: "Vulnerability scan report"
  },
  {
    question: "15. How often should incident response plans be tested?",
    options: ["Only after an actual incident", "Monthly", "Annually or whenever there’s a significant change", "Once at deployment"],
    correctAnswer: "Annually or whenever there’s a significant change"
  }
];

const container = document.getElementById("questions-container");

questionsData.forEach((q, index) => {
  const div = document.createElement("div");
  div.className = "question";
  div.innerHTML = `
    <h3>${q.question}</h3>
    <div class="options">
      ${q.options
        .map(opt => `<label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label>`)
        .join("")}
    </div>
  `;
  container.appendChild(div);
});

let duration = 15 * 60;
const timerDisplay = document.getElementById("timer");

const timer = setInterval(() => {
  const minutes = String(Math.floor(duration / 60)).padStart(2, "0");
  const seconds = String(duration % 60).padStart(2, "0");
  timerDisplay.textContent = `${minutes}:${seconds}`;
  duration--;
  if (duration < 0) {
    clearInterval(timer);
    alert("Time's up! Submitting your test...");
    document.getElementById("submit-btn").click();
  }
}, 1000);

document.getElementById("submit-btn").addEventListener("click", () => {
  clearInterval(timer);

  let score = 0;
  questionsData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    if (selected && selected.value === q.correctAnswer) {
      score++;
    }
  });

  const resultBox = document.createElement("div");
  resultBox.style.background = "#dff0d8";
  resultBox.style.border = "1px solid #3c763d";
  resultBox.style.color = "#3c763d";
  resultBox.style.padding = "1.5rem";
  resultBox.style.margin = "2rem auto";
  resultBox.style.width = "80%";
  resultBox.style.borderRadius = "8px";
  resultBox.style.textAlign = "center";
  resultBox.innerHTML = `
    <h2>Test Completed ✅</h2>
    <p>Your Score: <strong>${score} / ${questionsData.length}</strong></p>
    <p>${
      score >= 12
        ? "Excellent job!"
        : score >= 8
        ? "Good effort! Keep practicing!"
        : "Don’t worry, review the material and try again."
    }</p>
  `;

  document.body.appendChild(resultBox);
});
